# Original list
original_list = ['apple', 'banana', 'orange', 'grape']

# Adding index starting from 1
indexed_list = list(enumerate(original_list, start=1))

# Displaying the result
print(indexed_list)
